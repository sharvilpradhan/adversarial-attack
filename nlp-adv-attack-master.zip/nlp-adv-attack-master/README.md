Project for CSC-522: Adversarial Attacks on Sentiment Classifiers

Download dataset: https://drive.google.com/open?id=1WvnQFXBpwspF1WMewSGOsDYepzmGcHJI
